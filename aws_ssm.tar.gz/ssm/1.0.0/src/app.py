import boto3
import time
from botocore.config import Config
from walkoff_app_sdk.app_base import AppBase

class AWSEC2(AppBase):
    __version__ = "1.0.0"
    app_name = "AWS SSM"

    def __init__(self, redis, logger, console_logger=None):
        super().__init__(redis, logger, console_logger)

    def auth_ssm(self, access_key, secret_key, region):
        config = Config(
            region_name=region,
            signature_version='v4',
            retries={
                'max_attempts': 10,
                'mode': 'standard'
            },
        )
        return boto3.client(
            'ssm',
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
            config=config
        )

    def send_ssm_command(self, access_key, secret_key, region, instance_ids, command):
        """
        Sends a shell command to specified EC2 instances using AWS SSM and returns the output.
        """
        ssm = self.auth_ssm(access_key, secret_key, region)

        try:
            response = ssm.send_command(
                InstanceIds=instance_ids,
                DocumentName="AWS-RunShellScript",
                Parameters={
                    'commands': [command]
                }
            )
            command_id = response['Command']['CommandId']

            results = {}

            for instance_id in instance_ids:
                waited = 0
                while waited < 60:
                    output = ssm.get_command_invocation(
                        CommandId=command_id,
                        InstanceId=instance_id
                    )
                    if output['Status'] in ['Success', 'Failed', 'Cancelled', 'TimedOut']:
                        results[instance_id] = {
                            'stdout': output.get('StandardOutputContent', ''),
                            'stderr': output.get('StandardErrorContent', ''),
                            'status': output['Status']
                        }
                        break
                    time.sleep(2)
                    waited += 2
                else:
                    results[instance_id] = {
                        'stdout': '',
                        'stderr': 'Timeout waiting for command result',
                        'status': 'Timeout'
                    }

            return results

        except Exception as e:
            return f"Error sending or retrieving SSM command: {str(e)}"


# If this were a standalone test:
if __name__ == "__main__":
    AWSEC2.run()

